import 'package:flutter/material.dart';
import 'evento.dart';

class TelaCrudEventos extends StatelessWidget {
  final Function adicionarEvento;

  TelaCrudEventos({required this.adicionarEvento});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Evento'),
      ),
      body: AdicionarEventoForm(adicionarEvento: adicionarEvento),
    );
  }
}

class AdicionarEventoForm extends StatefulWidget {
  final Function adicionarEvento;

  AdicionarEventoForm({required this.adicionarEvento});

  @override
  _AdicionarEventoFormState createState() => _AdicionarEventoFormState();
}

class _AdicionarEventoFormState extends State<AdicionarEventoForm> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nomeController = TextEditingController();
  final TextEditingController _descricaoController = TextEditingController();

  DateTime _dataSelecionada = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: ListView(
        padding: EdgeInsets.all(20.0),
        children: <Widget>[
          TextFormField(
            controller: _nomeController,
            decoration: InputDecoration(labelText: 'Nome do Evento'),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor, insira o nome do evento';
              }
              return null;
            },
          ),
          TextFormField(
            controller: _descricaoController,
            decoration: InputDecoration(labelText: 'Descrição do Evento'),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor, insira a descrição do evento';
              }
              return null;
            },
          ),
          SizedBox(height: 20),
          TextButton(
            onPressed: _mostrarDatePicker,
            child: Text('Selecionar Data'),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _submitForm,
            child: Text('Adicionar Evento'),
          ),
        ],
      ),
    );
  }

  void _mostrarDatePicker() {
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    ).then((dataSelecionada) {
      if (dataSelecionada == null) return;
      setState(() {
        _dataSelecionada = dataSelecionada;
      });
    });
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final novoEvento = Evento(
        id: DateTime.now().toString(),
        nome: _nomeController.text,
        descricao: _descricaoController.text,
        data: _dataSelecionada,
      );
      widget.adicionarEvento(novoEvento);
      Navigator.pop(context);
    }
  }
}
