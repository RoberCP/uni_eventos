class Evento {
  final String id;
  final String nome;
  final String descricao;
  final DateTime data;

  Evento({
    required this.id,
    required this.nome,
    required this.descricao,
    required this.data,
  });

  String get dataFormatada {
    return '${data.day}-${data.month}-${data.year}';
  }
}
