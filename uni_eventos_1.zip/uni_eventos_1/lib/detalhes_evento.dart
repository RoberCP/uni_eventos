import 'package:flutter/material.dart';
import 'evento.dart';
import 'tela_editar_evento.dart';

class DetalhesEvento extends StatelessWidget {
  final Evento evento;
  final Function(Evento) onDelete;
  final Function(Evento) onUpdate;

  DetalhesEvento({required this.evento, required this.onDelete, required this.onUpdate});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalhes do Evento'),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              _editarEvento(context); 
            },
          ),
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () {
              _confirmarDelecao(context); 
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              evento.nome,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Text('Descrição: ${evento.descricao}'),
            SizedBox(height: 8),
            Text('Data: ${evento.data.day}-${evento.data.month}-${evento.data.year}'),
          ],
        ),
      ),
    );
  }

  void _editarEvento(BuildContext context) async {
    final updatedEvento = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TelaEditarEvento(evento: evento, onUpdate: onUpdate)),
    );

    if (updatedEvento != null) {
      onUpdate(updatedEvento);
    }
  }

  void _confirmarDelecao(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirmar Deleção'),
          content: Text('Tem certeza de que deseja deletar este evento?'),
          actions: <Widget>[
            TextButton(
              child: Text('Cancelar'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Deletar'),
              onPressed: () {
                onDelete(evento);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
