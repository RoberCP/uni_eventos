import 'package:flutter/material.dart';
import 'tela_mapa.dart';
import 'tela_crud_eventos.dart';
import 'evento.dart';
import 'detalhes_evento.dart';

class TelaPrincipal extends StatefulWidget {
  @override
  _TelaPrincipalState createState() => _TelaPrincipalState();
}

class _TelaPrincipalState extends State<TelaPrincipal> {
  List<Evento> _eventos = [
    Evento(id: '1', nome: 'Semana de Tecnologia', descricao: 'Uma semana dedicada às últimas tendências em tecnologia.', data: DateTime(2024, 7, 15)),
    Evento(id: '2', nome: 'Palestra sobre Inteligência Artificial', descricao: 'Discussão sobre os avanços e aplicações da IA na indústria.', data: DateTime(2024, 8, 20)),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'UniEventos',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Color.fromARGB(255, 78, 102, 243),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 78, 102, 243),
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Color.fromARGB(255, 127, 187, 236),
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.event, color: Color.fromARGB(255, 15, 95, 234)),
              title: Text(
                'Eventos',
                style: TextStyle(color: Color.fromARGB(255, 15, 95, 234)),
              ),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.map, color: Color.fromARGB(255, 15, 95, 234)),
              title: Text(
                'Mapa',
                style: TextStyle(color: Color.fromARGB(255, 15, 95, 234)),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TelaMapa()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.add, color: Color.fromARGB(255, 15, 95, 234)),
              title: Text(
                'Adicionar Evento',
                style: TextStyle(color: Color.fromARGB(255, 15, 95, 234)),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TelaCrudEventos(adicionarEvento: adicionarEvento)),
                );
              },
            ),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: _eventos.length,
        itemBuilder: (context, index) {
          return Card(
            color: Color.fromARGB(255, 15, 95, 234),
            elevation: 3,
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            child: ListTile(
              title: Text(
                _eventos[index].nome,
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
              ),
              subtitle: Text(
                _eventos[index].dataFormatada,
                style: TextStyle(color: Color.fromARGB(255, 127, 187, 236)),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DetalhesEvento(
                      evento: _eventos[index],
                      onDelete: _removerEvento,
                      onUpdate: _atualizarEvento,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  void adicionarEvento(Evento novoEvento) {
    setState(() {
      _eventos.add(novoEvento);
    });
  }

  void _removerEvento(Evento evento) {
    setState(() {
      _eventos.remove(evento);
    });
  }

  void _atualizarEvento(Evento eventoAtualizado) {
    setState(() {
      final index = _eventos.indexWhere((element) => element.id == eventoAtualizado.id);
      if (index != -1) {
        _eventos[index] = eventoAtualizado;
      }
    });
  }
}
