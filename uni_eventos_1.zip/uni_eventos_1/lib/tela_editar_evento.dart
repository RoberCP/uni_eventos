import 'package:flutter/material.dart';
import 'evento.dart';

class TelaEditarEvento extends StatefulWidget {
  final Evento evento;
  final Function(Evento) onUpdate;

  TelaEditarEvento({required this.evento, required this.onUpdate});

  @override
  _TelaEditarEventoState createState() => _TelaEditarEventoState();
}

class _TelaEditarEventoState extends State<TelaEditarEvento> {
  late TextEditingController _nomeController;
  late TextEditingController _descricaoController;

  @override
  void initState() {
    super.initState();
    _nomeController = TextEditingController(text: widget.evento.nome);
    _descricaoController = TextEditingController(text: widget.evento.descricao);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Editar Evento'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Nome do Evento:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            TextFormField(
              controller: _nomeController,
              decoration: InputDecoration(
                hintText: 'Digite o nome do evento',
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Descrição:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            TextFormField(
              controller: _descricaoController,
              decoration: InputDecoration(
                hintText: 'Digite a descrição do evento',
              ),
              maxLines: 3,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                _salvarAlteracoes();
              },
              child: Text('Salvar Alterações'),
            ),
          ],
        ),
      ),
    );
  }

  void _salvarAlteracoes() {
    Evento eventoAtualizado = Evento(
      id: widget.evento.id,
      nome: _nomeController.text,
      descricao: _descricaoController.text,
      data: widget.evento.data,
    );
    widget.onUpdate(eventoAtualizado);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Alterações salvas com sucesso!'),
    ));
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _descricaoController.dispose();
    super.dispose();
  }
}
